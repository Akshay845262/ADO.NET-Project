﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Registration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dreader;
        FileUpload FileUpload1;
        private object comboBox2;
        int rno = 0;

        FileStream fs;
        BinaryReader br;

        MemoryStream ms;
        private object student3;
        private object student3TableAdapter;
        private object studentInfoDataSet;

        public object ConfigurationManager { get; private set; }
        public byte[] ImageData { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
               OpenFileDialog op = new OpenFileDialog();
            op.Filter = "image Files (*.jpg; *.jpeg; *.gif;)|*.jpg; *.jpeg; *.gif";
            if (op.ShowDialog() == DialogResult.OK)
            {
                path.Text = op.FileName;
                photo.Image = new Bitmap(op.FileName);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentInfoDataSet.student3' table. You can move, or remove it, as needed.
           // this.student3TableAdapter.Fill(this.studentInfoDataSet.student3);
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = studentInfo; Integrated security = True ");
            con.Open();
            MessageBox.Show("Connection Established");        
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            String Filename = path.Text;
            byte[] ImageData;
            fs = new FileStream(Filename, FileMode.Open, FileAccess.Read);
            br = new BinaryReader(fs);
            ImageData = br.ReadBytes((int)fs.Length);
            br.Close();
            fs.Close();
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into student3(Id, Sname, Cname, Fees, StartDate, photo) values(@a,@b,@c,@d,@e,@f)", con);
            cmd.Parameters.AddWithValue("@a", Id.Text);
            cmd.Parameters.AddWithValue("@b", Sname.Text);
            cmd.Parameters.AddWithValue("@c", Cname.Text);
            cmd.Parameters.AddWithValue("@d", Fees.Text);
            cmd.Parameters.AddWithValue("@e", StartDate.Value.Date);
            cmd.Parameters.AddWithValue("@f", ImageData);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Inserted");
            con.Close();
        }

        private void Id_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Id.Clear();
            Sname.Clear();
            Cname.Clear();
            Fees.Clear();
           StartDate.Value = DateTimePicker.MinimumDateTime;
            // StartDate.CustomFormat = " ";
            //  StartDate= null;
            photo.Image = null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure want to exit ?", "Exit Application ", MessageBoxButtons.YesNo)==DialogResult.Yes) ;
            {
                SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
                con.Open();
                con.Close();
                con = null;
                MessageBox.Show("No connection is open", "Database Connection");
                Application.Exit();

            }
           
        }

        private void button11_Click(object sender, EventArgs e)
        {
           

            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            cmd = new SqlCommand("select * from student3 where Id =" + Id.Text + " ", con);

          /*  SqlDataAdapter da = new SqlDataAdapter("Select * from student3 where StartDate = '" + StartDate.Text + "'", con);

            DataSet ds = new DataSet();
            da.Fill(ds, "Student3");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Student3"; */

            dreader = cmd.ExecuteReader();
                  if (dreader.Read())
                  {
                      Id.Text = dreader[0].ToString();
                      Sname.Text = dreader[1].ToString();
                      Cname.Text = dreader[2].ToString();
                      Fees.Text = dreader[3].ToString();
                      StartDate.Text = dreader[4].ToString();
                   //  StartDate.Value = dreader.GetDateTime(4);


                  }
                  dreader.Close();

                  SqlDataAdapter da = new SqlDataAdapter(cmd);
                  DataSet ds = new DataSet();
                  da.Fill(ds, "Student3");

                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "Student3";

                  if (ds.Tables[0].Rows.Count > 0)
                  {
                      MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);
                      photo.Image = new Bitmap(ms);

                  }
                  else
                  {
                      MessageBox.Show("No Records");

                  }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            string query;
            query = "delete from student3 where Id= '" + Id.Text + "' ";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted");
        }


        void conv_photo()
        {
            //converting photo to binary data  
            if (photo.Image != null)
            {
                //using FileStream:(will not work while updating, if image is not changed)  
                //FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);  
                //byte[] photo_aray = new byte[fs.Length];  
                //fs.Read(photo_aray, 0, photo_aray.Length);    

                //using MemoryStream:  
                ms = new MemoryStream();
                photo.Image.Save(ms, ImageFormat.Jpeg);
                byte[] ImageData = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(ImageData, 0, ImageData.Length);
                cmd.Parameters.AddWithValue("@photo", ImageData);
            }
        }


        private void button10_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
              con.Open();
              cmd = new SqlCommand("Update student3 set id= '" + Id.Text + "', Sname = '" + Sname.Text + "', Cname = '" + Cname.Text + "', Fees = '" + Fees.Text + "', StartDate= '"+StartDate.Value.Date + "', photo=@photo where Id =" + Id.Text + " ", con);
            conv_photo();
         //   con.Open();
        //    con.Close();
            int n = cmd.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {
                MessageBox.Show("Record Updated");
                //loaddata();
            }
            else
                MessageBox.Show("Updation Failed");
          }  
               

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            string query;
            query = "Select * from student3 where Id = (Select max(Id)from student3)";

            cmd = new SqlCommand(query, con);
            dreader = cmd.ExecuteReader();
            if (dreader.Read())
            {
                Id.Text = dreader[0].ToString();
                Sname.Text = dreader[1].ToString();
                Cname.Text = dreader[2].ToString();
                Fees.Text = dreader[3].ToString();
                StartDate.Text = dreader[4].ToString();

            }
            dreader.Close();
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            dt.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);
                photo.Image = new Bitmap(ms);
            }
            else
            {
                MessageBox.Show("No more record");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            string query;
            query = "Select * from student3 where Id = (Select min(Id)from student3)";

            cmd = new SqlCommand(query, con);
            dreader = cmd.ExecuteReader();
            if (dreader.Read())
            {
                Id.Text = dreader[0].ToString();
                Sname.Text = dreader[1].ToString();
                Cname.Text = dreader[2].ToString();
                Fees.Text = dreader[3].ToString();
                StartDate.Text = dreader[4].ToString();
                //photo.Image =ImageData;
            }
            dreader.Close();
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            dt.Fill(ds);
            if(ds.Tables[0].Rows.Count > 0)
            {
                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);
                photo.Image = new Bitmap(ms);
            }
            else
            {
                MessageBox.Show("No more record");
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            //if (Id.Text != "")

            //{
                SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
                con.Open();
                string query;
                cmd = new SqlCommand("select * from student3 where Id <(select Id from student3 where Id= '" + Id.Text + "') order by id desc",con);
                //cmd = new SqlCommand(query, con);
                dreader = cmd.ExecuteReader();

                if (dreader.Read())
                {
                    Id.Text = dreader[0].ToString();
                    Sname.Text = dreader[1].ToString();
                    Cname.Text = dreader[2].ToString();
                    Fees.Text = dreader[3].ToString();
                StartDate.Text = dreader[4].ToString();

            }
            dreader.Close();
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            dt.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);
                photo.Image = new Bitmap(ms);
            }
            else

                {
                    MessageBox.Show("No more record");
                }
                dreader.Close();
            //}
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (Id.Text != "")

            {
                SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
                con.Open();
                string query;
                cmd = new SqlCommand("select * from student3 where Id > (select Id from student3 where Id= '" + Id.Text + "')",con);
                //cmd = new SqlCommand(query, con);
                dreader = cmd.ExecuteReader();

                if (dreader.Read())
                {
                    Id.Text = dreader[0].ToString();
                    Sname.Text = dreader[1].ToString();
                    Cname.Text = dreader[2].ToString();
                    Fees.Text = dreader[3].ToString();
                    StartDate.Text = dreader[4].ToString();

                }
                dreader.Close();
                SqlDataAdapter dt = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                dt.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);
                    photo.Image = new Bitmap(ms);
                }
                else
                {
                    MessageBox.Show("No more record");
                }

            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            //string sql = "SELECT * FROM student3";
           
            SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3", con);
            DataSet ds = new DataSet();
            dt.Fill(ds, "student3");
           // con.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Student3";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void StartDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fees_TextChanged(object sender, EventArgs e)
        {

        }

        private void StartDate_ValueChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();
            if (StartDate.Value == DateTimePicker.MinimumDateTime)
            {
                StartDate.Value = DateTime.Now; // This is required in order to show current month/year when user reopens the date popup.
                StartDate.Format = DateTimePickerFormat.Custom;
                StartDate.CustomFormat = " ";
            }
            else
            {
                StartDate.Format = DateTimePickerFormat.Short;
            }
            /*    SqlDataAdapter da = new SqlDataAdapter("Select * from student3 where StartDate = '"+StartDate.Text+"'", con);

                DataSet ds = new DataSet();
                da.Fill(ds, "Student3");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Student3";*/
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Server = BLT213\\SQLEXPRESS; DataBase = StudentInfo; Integrated security = True ");
            con.Open();

            SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3 where Cname='"+comboBox1.Text+"'" , con);
            DataSet ds = new DataSet();
            dt.Fill(ds, "studentInfo");
            // con.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "studentInfo";

            /*    string str = comboBox1.Text;
               if(str=="All")
               {
                   SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3", con);
                   DataSet ds = new DataSet();
                   dt.Fill(ds, "studentInfo");
                   // con.Close();
                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "studentInfo";
               }

               else if (str == "Java")
               {
                   SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3 where Cname ='Java'", con);
                   DataSet ds = new DataSet();
                   dt.Fill(ds, "studentInfo");
                   // con.Close();
                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "studentInfo";
               }

               else if (str == "Python")
               {
                   SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3 where Cname ='Python'", con);
                   DataSet ds = new DataSet();
                   dt.Fill(ds, "studentInfo");
                   // con.Close();
                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "studentInfo";
               }
               else if (str == "Testing")
               {
                   SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3 where Cname ='Testing'", con);
                   DataSet ds = new DataSet();
                   dt.Fill(ds, "studentInfo");
                   // con.Close();
                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "studentInfo";
               }
               else if (str == "ML")
               {
                   SqlDataAdapter dt = new SqlDataAdapter("SELECT * FROM student3 where Cname ='ML'", con);
                   DataSet ds = new DataSet();
                   dt.Fill(ds, "studentInfo");
                   // con.Close();
                   dataGridView1.DataSource = ds;
                   dataGridView1.DataMember = "studentInfo";
               } */
        }

        private void photo_Click(object sender, EventArgs e)
        {

        }

        private void path_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

