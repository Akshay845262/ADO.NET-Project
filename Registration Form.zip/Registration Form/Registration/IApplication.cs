﻿namespace Registration
{
    internal interface IApplication
    {
    }
}